<HTML>
<HEAD>
<TITLE>Test PHP Page</TITLE>
</HEAD>

<BODY>
<? phpinfo(); ?>

</BODY>
</HTML>
