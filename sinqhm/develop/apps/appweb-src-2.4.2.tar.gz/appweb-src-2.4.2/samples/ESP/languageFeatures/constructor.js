//
//	Constructor test
//

function MyFunc(a, b) {
}

var o = new MyFunc(1, 2);

println("o.toString = " + o.toString);
println(o);
println("o.toValue = " + o.toValue);

var b = new Boolean();

