//
//	Assign 3 to i.
//
i=3;
