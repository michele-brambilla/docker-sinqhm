//
//	Comment test
//

/* C style comments are okay too */

var x;		// Comments should work at the end of the line also

var y;
