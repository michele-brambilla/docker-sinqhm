//
//	null test
//

//	Should work
var x;

// println("x is " + x);

assert(x == undefined);

x = null;

// println("x is " + x);

assert(x == null);

