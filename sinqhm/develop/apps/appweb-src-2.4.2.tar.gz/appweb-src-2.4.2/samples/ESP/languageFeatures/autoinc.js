//
//	Auto inc / dec test
//

i = 0;
i++;
i--;

assert(i == 0);
