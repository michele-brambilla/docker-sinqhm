//
//	For test
//

j = 0;
for (i = 0; i < 50; i++) {
	j = j + i;
	assert(j == i + 1);
}
