//
//	Math test (need try / catch to use effectively)
//
var f;

var f = Infinity;

var f = NaN;

var a = 0.0 / 0.0;

assert(a == NaN);

//
//	try { a = 7 / x; }
//	catch { }
//b = x / 0;
//c = 7 / 0;
